#pragma once
#include"employee.h"
class manager:public employee
{
private:
	int teamsize;
	double budget;
public:
	manager(int, double, const char*, int, double);
	void setteamsize(int);
	void setbudget(double);
	int getteamsize()const;
	double getbudget()const;
	void display()const;
};

