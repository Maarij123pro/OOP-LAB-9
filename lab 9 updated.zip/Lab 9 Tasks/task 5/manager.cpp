#include "manager.h"
#include<iostream>
using namespace std;
manager::manager(int ts, double b, const char* n, int i, double s) :employee(n, i, s)
{
	teamsize = ts;
	budget = b;
}
void manager::setteamsize(int ts)
{
	teamsize = ts;
}
void manager::setbudget(double b)
{
	budget = b;
}
int manager::getteamsize()const
{
	return teamsize;
}
double manager::getbudget()const
{
	return budget;
}
void manager::display()const
{
	cout << "The employee name is:" << getname() << endl;
	cout << "The employee Id is:" << getid() << endl;
	cout << "The employee Salary is:" << getsalary() << endl;
	cout << "The Team size is:" << teamsize << endl;
	cout << "The budget is:" << budget << endl;
}