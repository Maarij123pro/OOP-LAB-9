#pragma once
class employee
{
private:
	char* name;
	int id;
	double salary;
public:
	employee(const char* ,int, double);
	void setname(const char*);
	void setid(int);
	void setsalary(double);
	const char* getname()const;
	int getid()const;
	double getsalary()const;
};

