#include "employee.h"
#include<cstring>
employee::employee(const char* n, int i, double sal)
{
	int len = strlen(n) + 1;
	name = new char[len];
	strcpy_s(name, len, n);
	id = i;
	salary = sal;
}
void employee::setname(const char* n)
{
	int len = strlen(n) + 1;
	name = new char[len];
	strcpy_s(name, len, n);
}
void employee::setid(int  i)
{
	id = i;
}
void employee::setsalary(double s)
{
	salary = s;
}
const char* employee::getname()const
{
	return name;
}
int employee::getid()const
{
	return id;
}
double employee::getsalary()const
{
	return salary;
}