#include"manager.h"
#include<iostream>
using namespace std;
int main()
{
	cout << "Parametrized Costructor:-" << endl;
	manager m1(12, 12000, "Maarij", 123, 10000);
	m1.display();
	cout << "------------------------------------" << endl;

	cout << "Getter Functions:-" << endl;
	cout << m1.getname() << endl;
	cout << m1.getid() << endl;
	cout << m1.getsalary() << endl;
	cout << m1.getteamsize() << endl;
	cout << m1.getbudget() << endl;
	cout << "------------------------------------" << endl;



	return 0;
}