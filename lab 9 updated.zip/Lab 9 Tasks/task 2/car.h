#pragma once
#include"vehicle.h"
class car:public vehicle
{
public:
	car();
};

