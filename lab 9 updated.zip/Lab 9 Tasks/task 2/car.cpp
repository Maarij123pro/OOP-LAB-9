#include "car.h"
#include<iostream>
using namespace std;
car::car()
{
	cout << "Car Created" << endl;
}
