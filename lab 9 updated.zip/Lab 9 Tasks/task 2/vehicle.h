#pragma once
class vehicle
{
private:
	int regno;
	char* brand;
public:
	vehicle();
};

