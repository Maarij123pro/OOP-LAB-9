#include "vehicle.h"
#include<iostream>
#include<cstring>
using namespace std;
vehicle::vehicle()
{
	regno = 0;
	brand = new char[10];
	strcpy_s(brand, 10, "Unknown");
	cout << "Vehicle Created." << endl;
}