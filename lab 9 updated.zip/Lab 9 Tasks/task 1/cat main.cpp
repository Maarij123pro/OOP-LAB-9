#include<iostream>
#include"cat.h"
using namespace std;
int main()
{
	cout << "Default Constructor:-" << endl;
	cat c1;
	c1.display();
	cout << "---------------------------------" << endl;

	cout << "Parametrized Constructor:-" << endl;
	cat c2("cat", 2, 1);
	c2.display();
	cout << "---------------------------------" << endl;

	return 0;
}