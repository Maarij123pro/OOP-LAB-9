#pragma once
#include"animal.h"
class cat :public animal
{
private:
	int numberofcats;
public:
	cat();
	cat(const char*,int,int);
};

