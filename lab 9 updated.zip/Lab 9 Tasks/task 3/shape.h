#pragma once
class shape
{
protected:
	char* colour;
	int sides;
public:
	shape(const char*, int);
};

