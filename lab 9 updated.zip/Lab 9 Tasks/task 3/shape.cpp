#include "shape.h"
#include<cstring>
#include<iostream>
using namespace std;
shape::shape(const char* c, int s)
{
	int len = strlen(c) + 1;
	colour = new char[len];
	strcpy_s(colour, len, c);
	sides = s;
}
