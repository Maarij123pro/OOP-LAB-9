#include "rectangle.h"
#include<iostream>
#include<cstring>
using namespace std;

rectangle::rectangle(const char* c, int s, double l, double w) :shape(c, s)
{
    length = l;
    width = w;
}
void rectangle::display()const
{
    cout << "The colour of the rectangle is:" << colour << endl;
    cout << "The sides of the rectangle are:" << sides << endl;
    cout << "The length of the rectangle is:" << length << endl;
    cout << "The width of the rectangle is:" << width << endl;
}