#include "airconditioner.h"
#include<iostream>
using namespace std;

airconditioner::airconditioner(const char* b, double p, int w):appaliance(b)
{
	price = p;
	warranty = w;
}
void airconditioner::dispaly()const
{
	cout << "The brand of the airconditioner is:" << brand << endl;
	cout << "The price of it is:" << price << endl;
	cout << "Its Warrenty is:" << warranty << ":Days." << endl;
}