#include"airconditioner.h"
#include<iostream>
using namespace std;
int main()
{
	airconditioner ac1("Hiaer", 120000, 200);
	ac1.dispaly();
	cout << "---------------------------------" << endl;

	return 0;
}