#pragma once
#include"shape.h"
class rectangle:public shape
{
private:
	double length;
	double width;
public:

	rectangle(const char*, int, double, double);
	void display()const;
};

