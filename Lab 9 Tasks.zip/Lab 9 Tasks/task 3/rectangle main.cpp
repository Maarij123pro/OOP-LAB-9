#include<iostream>
#include"rectangle.h"
using namespace std;
int main()
{
	rectangle r1("Blue", 4, 10.9, 12.5);
	r1.display();
	cout << "----------------------------" << endl;

	return 0;
}