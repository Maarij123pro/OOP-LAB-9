#include"car.h"
#include<iostream>
using namespace std;
int main()
{
	car c1;


	return 0;
}