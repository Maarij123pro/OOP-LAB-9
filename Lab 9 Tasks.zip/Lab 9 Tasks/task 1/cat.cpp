#include "cat.h"


cat::cat()
{

}
cat::cat(const char* name, int age, int number) :animal(name, age)
{
	numberofcats = number;
}