#pragma once
class animal
{
private:
	char* name;
	int age;
public:
	animal();
	animal(const char*, int);
	~animal();
	void display()const;
};

