#include "animal.h"
#include<cstring>
#include<iostream>
using namespace std;
animal::animal()
{
	name = new char[10];
	strcpy_s(name, 10, "Unknown");
	age = 0;
}
animal::animal(const char* n, int a)
{
	int len = strlen(n) + 1;
	name = new char[len];
	strcpy_s(name, len, n);
	age = a;
}
animal::~animal()
{
	delete[] name;
	name = nullptr;
}
void animal::display()const
{
	cout << "The name of the animal is:" << name << endl;
	cout << "The animal age is:" << age << endl;
}
