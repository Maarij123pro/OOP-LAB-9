#pragma once
#include"appaliance.h"
class airconditioner:public appaliance
{
private:
	double price;
	int warranty;
public:
	airconditioner(const char*, double, int);
	void dispaly()const;
};

