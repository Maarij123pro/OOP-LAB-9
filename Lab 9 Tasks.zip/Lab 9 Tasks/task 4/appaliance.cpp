#include "appaliance.h"
#include<cstring>

appaliance::appaliance(const char* b):brand(b)
{
}
