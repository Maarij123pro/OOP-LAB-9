#pragma once
class appaliance
{
protected:
	const char* brand;
public:
	appaliance(const char*);
	
};

